const Delay = (ms) => new Promise((res) => setTimeout(res, ms))

export default Delay